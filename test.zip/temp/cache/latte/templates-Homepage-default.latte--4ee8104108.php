<?php
// source: D:\xampp\htdocs\test\app\presenters/templates/Homepage/default.latte

use Latte\Runtime as LR;

class Template4ee8104108 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
		'title' => 'blockTitle',
	];

	public $blockTypes = [
		'content' => 'html',
		'title' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['user_info'])) trigger_error('Variable $user_info overwritten in foreach on line 20');
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>
<div id="banner">
<?php
		$this->renderBlock('title', get_defined_vars());
?>
</div>

<div>
    <a href="<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("User:adduser")) ?>">
        Add user <i class="fa fa-user-plus"></i>
    </a>
    <table id="user-list">
        <thead>
            <tr>
                <th>Jmeno</th>
                <th>Email</th>
                <th>Typ</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
<?php
		$iterations = 0;
		foreach ($users as $user_info) {
?>
                <tr>
                    <td><?php echo LR\Filters::escapeHtmlText($user_info->user_name) /* line 22 */ ?></td>
                    <td><?php echo LR\Filters::escapeHtmlText($user_info->email) /* line 23 */ ?></td>
                    <td><?php echo LR\Filters::escapeHtmlText($user_info->type) /* line 24 */ ?></td>
                    <td>
                        <a href = '<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("User:edituser", [$user_info->email])) ?>'>
                            <i class="fa fa-edit"></i>
                        </a>
                        <a href = '<?php echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("User:delete", [$user_info->email])) ?>'>
                            <i class="fa fa-trash" aria-hidden="true"></i>
                        </a>
                    </td>
                </tr>
<?php
			$iterations++;
		}
?>
        </tbody>
    </table>
</div>
<?php
	}


	function blockTitle($_args)
	{
		extract($_args);
?>	<h1>Vypis uzivatelu</h1>
<?php
	}

}
