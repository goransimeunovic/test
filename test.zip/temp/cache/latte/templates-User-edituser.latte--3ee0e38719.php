<?php
// source: D:\xampp\htdocs\test\app\presenters/templates/User/edituser.latte

use Latte\Runtime as LR;

class Template3ee0e38719 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>

<?php
		$form = $_form = $this->global->formsStack[] = $this->global->uiControl["editUser"];
		?><form class="form"<?php
		echo Nette\Bridges\FormsLatte\Runtime::renderFormBegin(end($this->global->formsStack), array (
		'class' => NULL,
		), false) ?>>
    <div class="user-form-header">
        <strong>Edit user</strong>
    </div>
    <div class="user-form-body user-block">
        <div class="row form-group">
            <div class="col col-md-3">
                <label for="username" class="form-control-label">
                    Jmeno uzivatele
                </label>
            </div>
            <div class="col-12 col-md-9">
                <input type="text" id="username" class="form-control"<?php
		$_input = end($this->global->formsStack)["username"];
		echo $_input->getControlPart()->addAttributes(array (
		'type' => NULL,
		'id' => NULL,
		'class' => NULL,
		))->attributes() ?>>
            </div>
        </div>
        <div class="row form-group">
            <div class="col col-md-3">
                <label for="email" class="form-control-label">
                    Email
                </label>
            </div>
            <div class="col-12 col-md-9">
                <input type="email" id="email" class="form-control"<?php
		$_input = end($this->global->formsStack)["email"];
		echo $_input->getControlPart()->addAttributes(array (
		'type' => NULL,
		'id' => NULL,
		'class' => NULL,
		))->attributes() ?>>
            </div>
        </div>
        <div class="row form-group">
            <div class="col col-md-3">
                <label for="type" class=" form-control-label">
                    Typ
                </label>
            </div>
            <div class="col-12 col-md-9">
                <select id="type" class="form-control" <?php
		$_input = end($this->global->formsStack)["type"];
		echo $_input->getControlPart()->addAttributes(array (
		'id' => NULL,
		'class' => NULL,
		))->attributes() ?>>
<?php echo $_input->getControl()->getHtml() ?>                </select>
            </div>
        </div>
                                    
        <div class="user-form-footer">
            <button type="submit" class="btn btn-primary btn-sm">
                <i class="fa fa-dot-circle-o"></i> Upravit uzivatele
            </button>
        </div>
    </div>
<?php
		echo Nette\Bridges\FormsLatte\Runtime::renderFormEnd(array_pop($this->global->formsStack), false);
?></form>
            
<?php
	}

}
