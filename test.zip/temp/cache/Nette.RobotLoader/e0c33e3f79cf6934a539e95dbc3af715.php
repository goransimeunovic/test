<?php
return array (
  0 => 
  array (
    'App\\Presenters\\BasePresenter' => 
    array (
      'file' => 'D:\\xampp\\htdocs\\test\\app\\presenters\\BasePresenter.php',
      'time' => 1636723609,
    ),
    'App\\Presenters\\Error4xxPresenter' => 
    array (
      'file' => 'D:\\xampp\\htdocs\\test\\app\\presenters\\Error4xxPresenter.php',
      'time' => 1636545745,
    ),
    'App\\Presenters\\ErrorPresenter' => 
    array (
      'file' => 'D:\\xampp\\htdocs\\test\\app\\presenters\\ErrorPresenter.php',
      'time' => 1636545745,
    ),
    'App\\Presenters\\HomepagePresenter' => 
    array (
      'file' => 'D:\\xampp\\htdocs\\test\\app\\presenters\\HomepagePresenter.php',
      'time' => 1637079177,
    ),
    'App\\Router\\RouterFactory' => 
    array (
      'file' => 'D:\\xampp\\htdocs\\test\\app\\router\\RouterFactory.php',
      'time' => 1636545745,
    ),
    'App\\Model\\UserManager' => 
    array (
      'file' => 'D:\\xampp\\htdocs\\test\\app\\model\\UserManager.php',
      'time' => 1637226426,
    ),
    'App\\Presenters\\UserPresenter' => 
    array (
      'file' => 'D:\\xampp\\htdocs\\test\\app\\presenters\\UserPresenter.php',
      'time' => 1637226793,
    ),
  ),
  1 => 
  array (
    'Nette\\Environment' => 18,
    'App\\Presenters\\AdduserModule\\PhpPresenter' => 1,
    'App\\Presenters\\AddPresenter' => 3,
    'AdduserPresenter' => 1,
    'App\\AdduserPresenter' => 2,
    'Presenters\\AdduserPresenter' => 3,
    'App\\Presenters\\AdduserPresenter' => 1,
    'App\\Presenters\\HompagePresenter' => 1,
    'App\\Presenters\\OrderPresenter' => 1,
  ),
);
